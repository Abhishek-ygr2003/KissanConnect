import React from 'react';
import {acData} from "../data/ac";
const fiveProducts = acData.slice(0, 5);
const AC= () => {
    return (
        <div className="productSection">
            {fiveProducts.map((item) => (
                <div key={item.id}>
                    <img src={item.image} alt={item.name} />
                </div>
            ))}
        </div>
    );
};

export default AC;
