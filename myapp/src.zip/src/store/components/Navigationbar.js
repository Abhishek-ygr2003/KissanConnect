import React from 'react';
import Userspage from '../pages/Userspage';
import Landingpage from '../pages/Landingpage';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Products from './Products';
import { Container, Nav, Navbar } from 'react-bootstrap';
import Computerpage from '../pages/Computerpage';
import Mobilepage from '../pages/Mobilepage';
import Fridgepage from '../pages/Fridgepage';

const Navigationbar = () => {
  return (
    <div>
      <BrowserRouter>
        <Navbar bg="dark" data-bs-theme="dark">
          <Container>
            <Navbar.Brand href="#home">Navbar</Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link as={Link} to="/">Home</Nav.Link>
              <Nav.Link as={Link} to="/products">Products</Nav.Link>
              <Nav.Link as={Link} to="/users">Users</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
        <ul className='subMenu'>
          <li><Link to = '/mobiles'>Mobiles</Link></li>
          <li><Link to = '/computers'>Computers</Link></li>
          <li><Link to = '/fridges'>Fridges</Link></li>
        </ul>
        <Routes>
          <Route path="/" element={<Landingpage />} />
          <Route path="/products" element={<Products />} />
          <Route path="/users" element={<Userspage />} />
          <Route path="/computers" element={<Computerpage />} />
          <Route path="/mobiles" element={<Mobilepage />} />
          <Route path="/fridges" element={<Fridgepage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default Navigationbar;
