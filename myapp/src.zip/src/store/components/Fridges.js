import React from 'react'
import { fridgeData } from '../data/fridge'
const fiveProduct = fridgeData.slice(0,5)
const Fridges = () => {
  return (
    <div className='productSection'>
      {fiveProduct.map((item) => (
        <div key={item.id}> {/* Assuming each item has a unique 'id' */}
          <img src={item.image} alt={item.name} /> {/* Updated the alt attribute */}
        </div>
        
      ))}
    </div>
  )
}

export default Fridges