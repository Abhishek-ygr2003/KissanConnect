import React from 'react'
import Computers from './Computers'
import Mobiles from './Mobiles'
import Acs from './Acs'
import Fridges from './Fridges'
const Products = () => {
  return (
    <div>
        <Computers />
        <Mobiles />
        <Acs />
        <Fridges />
    </div>
  )
}

export default Products