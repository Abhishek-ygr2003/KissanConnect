import React from 'react';
import {mobileData} from "../data/mobiles";
const fiveProducts = mobileData.slice(0, 5);
const Moblies = () => {
    return (
        <div className="productSection">
            {fiveProducts.map((item) => (
                <div key={item.id}>
                    <img src={item.image} alt={item.name} />
                </div>
            ))}
        </div>
    );
};

export default Moblies;
