import React from 'react'
import { acData } from '../data/ac'
const fiveProduct = acData.slice(0,5)

const Acs = () => {
  return (
    <div className='productSection'>
      {fiveProduct.map((item) => (
        <div key={item.id}> {/* Assuming each item has a unique 'id' */}
          <img src={item.image} alt={item.name} /> {/* Updated the alt attribute */}
        </div>
      ))}
    </div>
  )
}

export default Acs