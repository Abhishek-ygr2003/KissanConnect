import React from 'react'

const Productspage = () => {
  return (
    <div>Productspage</div>
  )
}

export default Productspage