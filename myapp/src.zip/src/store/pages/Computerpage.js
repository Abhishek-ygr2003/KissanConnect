import React from 'react'
import { computerData } from '../data/computers'
const Computerpage = () => {
    return (
      <div className='pageSection'>
        {computerData.map((item) => (
          <div key={item.id}> {/* Assuming each item has a unique 'id' */}
            <img src={item.image} alt={item.name} /> {/* Updated the alt attribute */}
          </div>
        ))}
      </div>
    );
  }
  

export default Computerpage