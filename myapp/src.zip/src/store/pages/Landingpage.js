import React from 'react'

const Landingpage = () => {
  return (
    <div>Landingpage</div>
  )
}

export default Landingpage